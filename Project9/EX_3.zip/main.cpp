#include"College.h"
int main()
{
	College sce;
	sce.menu();
	return 0;
}